<?php
include("header.php");
?>


<div align="center">
<form name="form1" method="post" action="checklogin.php">

<table>

<tr>
<td align="center"><strong>Admin Login</strong></td>
</tr>

<tr>
<td><img src="img/user.png">
<input name="myusername" type="text" id="myusername"></td>
</tr>

<tr>
<td><img src="img/pass.png">
<input name="mypassword" type="password" id="mypassword"></td>
</tr>

<tr>
<td align="center" colspan="2"><br><input type="submit" name="Submit" value="Log me into AP"></td>
</tr>

</table>

</form>

</div> 



<?php
include("footer.php");
?>