<? 
session_start();
if(!session_is_registered(myusername)){
header("location:admin_login.php");
}
?>


<?php
include("header.php");
?>
<center>
<font face="Comic Sans Ms" size="3" color="purple">iReal Admin Panel</font><br><br>

<font face="Trebuchet Ms" size="2,8" color="silver"><a href="admin_details.php">� Detailii Conturi si modificare user</a></font><br>
<font face="Trebuchet Ms" size="2,8" color="silver"><a href="admin_adduser.php">� Adauga utilizator</a></font><br>
<font face="Trebuchet Ms" size="2,8" color="silver"><a href="admin_addadmin.php">� Adauga Admin</a></font><br>
<font face="Trebuchet Ms" size="2,8" color="silver"><a href="admin_deladmin.php">� Vizualizare Admini si Stergere Admin</a></font>

</center>









<?php
include("footer.php");
?>