<?php
include("header.php");
?>
   
<div align="center">
<br>
<font size="1">
<form action="take_statistici.php" method="post">
<table>
<tr>
<td><img src="img/user.png"></td><td align="right"><input name="username" type="text" size="28" maxlength="20" id="username" class="tbox" /></td>
</tr><tr>
<td><img src="img/pass.png"></td></td><td align="right"><input name="password" type="password" size="28" maxlength="20" id="password" class="tbox" /></td>
</tr><tr>
<td align="center" colspan="2">
<br><input name="submit" type="submit" value="Log me" class="button" /></td>
</tr>
</table>
</form>

</div> 

<?php
include("footer.php");
?>