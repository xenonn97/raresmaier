<?php

// Parametri SQL

$_mysql_host="localhost"; // Host baza de date
$_mysql_db="pgzro_conurs"; // Baza de date
$_mysql_user="pgzro_conurs"; // User baza de date
$_mysql_password="#concurs123"; // Parola baza de date
$conexiune = mysql_connect($_mysql_host,$_mysql_user,$_mysql_password) or die("a.Nu ma pot conecta la MySQL!");
mysql_select_db($_mysql_db, $conexiune) or die("Nu gasesc baza de date");
?>