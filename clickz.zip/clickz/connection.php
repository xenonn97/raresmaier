<?php
$host="mysql.x90x.net"; // Host name 
$username="u971606909_click"; // Mysql username 
$password="07121995"; // Mysql password 
$db_name="u971606909_click"; // Database name 
$tbl_name="admins"; // Table name 
$tbl_name_users="users"; //Table name
?>