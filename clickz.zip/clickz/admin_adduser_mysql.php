<?php
include("connection.php");

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];
$clickz=$_POST['clickz'];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name_users(username, password, email, clickz)VALUES('$username', '$password', '$email', '$clickz')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "<font color='green' size='4'>Insert Users:Successful</font>";
echo "<BR>";
echo "<a href='login_success.php'>Back to main page</a>";
}

else {
echo "<font color='red' size='4'>ERROR</font>";
}

// close connection 
mysql_close();
?>