<?php
include("header.php");
?>
<div align="center">
<table>
<tr><td class="title" colspan="3">Top 100</td></tr>
<tr><td class='id100'>Rank</td><td class='username100'>Concurent</td><td class='clickz100'>Clickz</td></tr>
<?php

// Conectare MySQL
require ('config.php');
//

$result = mysql_query("SELECT * FROM users ORDER BY clickz");

$rank = 1;
while($row = mysql_fetch_array($result))
  {
  $username = $row['username'];
  $clickz = $row['clickz'];
  print("<tr><td class='id100'>$rank</td><td class='username100'><a href='clickz.php?player=$username'>$username</a></td><td class='clickz100'>$clickz</td></tr>");
  $rank++;
  }
?>
</table>
</div>
 
<?php
include("footer.php");
?>