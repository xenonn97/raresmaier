<? 
session_start();
if(!session_is_registered(myusername)){
header("location:admin_login.php");
}
?>
<?php

include("connection.php");

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// select record from mysql 
$sql="SELECT * FROM $tbl_name_users";
$result=mysql_query($sql);

?>
<?php
include("header.php");
?>


<div align="center">
<table>
<tr><td class="title" colspan="7"><font face="Comic Sans Ms" size="2,1">Admin: User details</font></td></tr>
<tr><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Rank</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Player</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Clickz</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Parola</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Email</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Reg. Date</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">IP</font></td><td class='clickz100'><font color="green" face="Trebuchet Ms" size="2">Delete?</font></td></tr>
<?php
while($rows=mysql_fetch_array($result)){
?>
<?php

// Conectare MySQL
require ('config.php');
//

$result = mysql_query("SELECT * FROM users ORDER BY clickz DESC LIMIT 100");

$rank = 1;
while($row = mysql_fetch_array($result))
  {
  $username = $row['username'];
  $clickz = $row['clickz'];
  $email = $row['email'];
  $password = $row['password'];
  $date = $row['date'];
  $ip = $row['ip'];
  $id=$rows['id'];
  //$player = $row['username'];
  
  print("<tr><td class='id100'>$rank</td><td class='username100'><a href='admin_clickz.php?player=$username'>$username</a></td><td class='clickz100'>$clickz</td><td class='clickz100'>$password</td><td class='clickz100'>$email</td><td class='clickz100'>$date</td><td class='clickz100'>$ip</td><td class='clickz100'><a href='admin_deluser_ac.php?id=$id'>delete</a></td></tr>");
  $rank++;
  }
?>

<?

// close while loop 
}

// close connection; 
mysql_close();

?>
</table>
</div>



<?php
include("footer.php");
?>