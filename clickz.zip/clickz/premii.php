<?php
include("header.php");
?>
   
   
   
   		<div style='text-align:center'><span class='premiu1'>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Un tricou personalizat cu site-ul iReal . &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      
    </div> <br>
	
	   		<div style='text-align:center'><span class='premiu2'>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Set 12 stickere cu site-ul Ireal .  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
    </div> <br>
	
	   		<div style='text-align:center'><span class='premiu3'>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.000 clickz-uri la urmatorul concurs de luna viitoare . &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      
    </div>
	<center><h5>* Deoarece este prima editie a concursului iReal Clickz , premile vor fi mai neinsemnate .<p> O data cu cresterea numarului de editii ale concursului , vom adauga premii mai valoroase ! <p> Multumim pentru intelegere !
	</h5></center>
	        
           
<?php
include("footer.php");
?>