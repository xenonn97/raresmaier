

<?php

$rip = $_SERVER['REMOTE_ADDR'];
$sd  = time();
$count = 1;

$file1 = "hahaha.txt";
$lines = file($file1);
$line2 = "";

foreach ($lines as $line_num => $line)
	{
		//echo $line."<br>";
		$fp = strpos($line,'****');
		$nam = substr($line,0,$fp);
		$sp = strpos($line,'++++');
		$val = substr($line,$fp+4,$sp-($fp+4));
		$diff = $sd-$val;
		if($diff < 300 && $nam != $rip)
			{
			 $count = $count+1;
			 $line2 = $line2.$line;
			 //echo $line2; 
			}
	}

$my = $rip."****".$sd."++++\n";
$open1 = fopen($file1, "w");
fwrite($open1,"$line2");
fwrite($open1,"$my");
fclose($open1);

echo "<font color=#ffffff><b>$count</b> Useri Online</b></font></span>";

?>
