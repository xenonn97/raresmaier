<? 
session_start();
if(!session_is_registered(myusername)){
header("location:admin_login.php");
}
?>


<?php
 include("header.php");
?>



<?php
include("connection.php");

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// select record from mysql 
$sql="SELECT * FROM $tbl_name";
$result=mysql_query($sql);

?><center>
<table width="400" border="0" cellspacing="1" cellpadding="0">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td bgcolor="#FFFFFF">&nbsp;</td>
<td colspan="4" bgcolor="#FFFFFF"><strong>Admin's</strong> </td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF"><strong>Id</strong></td>
<td align="center" bgcolor="#FFFFFF"><strong>Username</strong></td>
<td align="center" bgcolor="#FFFFFF"><strong>Password</strong></td>
<td align="center" bgcolor="#FFFFFF">&nbsp;</td>
</tr>
<?php
while($rows=mysql_fetch_array($result)){
?>
<tr>
<td bgcolor="#FFFFFF"><? echo $rows['id']; ?></td>
<td bgcolor="#FFFFFF"><? echo $rows['username']; ?></td>
<td bgcolor="#FFFFFF"><? echo $rows['password']; ?></td>
<td bgcolor="#FFFFFF"><a href="admin_deladmin_ac.php?id=<? echo $rows['id']; ?>">delete</a></td>
</tr>
<?

// close while loop 
}

// close connection; 
mysql_close();

?> 
</table></td>
</tr>
</table></center>





<?php
 include("footer.php");
?>