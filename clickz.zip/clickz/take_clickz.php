<?php

// Conectare MySQL
require ('config.php');
// -------------------

// Variabile
if(!isset($_POST['player'])){ 
    $username = "default";
} else { 
    $username = $_POST['player'];
} 


$go = $_COOKIE['clickz'];
$date = date('Y.m.d');
$userip = $_SERVER['REMOTE_ADDR'];


//----------
$verificare = "SELECT * FROM votes WHERE votefor = '$username' AND ip = '$userip' AND date = '$date'";
$verificare_vot = mysql_query($verificare);
//----------

if ($go != $date) {

       if(mysql_num_rows($verificare_vot) == 0) {

       
       $mesaj = "$username iti multumeste ca i-ai acordat un Clickz ! <br> Daca ii esti prieten ii vei da un Clickz si peste 12 ore.";
       setcookie("clickz", $date, time()+43200);
       mysql_query("INSERT INTO votes (votefor, ip, date) VALUES ('$username', '$userip', '$date')");
       mysql_query("UPDATE users SET clickz= clickz + 1 WHERE username= '$username'");
       } else { $mesaj = "Deja ai acordat un clickz <br> Deabea dupa 12 de ore vei putea oferi altul."; }

}

else

{ $mesaj = "Ai oferit deja un Clickz in ultimele 24 ore ! <br> Vino sa votezi si maine !"; } 

include("header.php");
print("<div align='center'>$mesaj</div>"); 
include("footer.php");
?>