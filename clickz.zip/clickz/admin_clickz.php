<? 
session_start();
if(!session_is_registered(myusername)){
header("location:admin_login.php");
}
?>


<?php
include("header.php");
?>



<?php
include("connection.php");



// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// get value of id that sent from address bar
$player=$_GET['username'];


// Retrieve data from database 
$sql="SELECT * FROM $tbl_name_users WHERE username='$player'";
$result=mysql_query($sql);

$rows=mysql_fetch_array($result);
?>

<div align="center">
<form name="form1" method="post" action="admin_clickz_up.php">



<strong><center>Modify user</center></strong><br><br>



<strong>Username<input name="username" type="text" id="username" value="Insert new username"></strong><br><br>

<strong>Password<input name="password" type="text" id="password" value="Insert new password" size="15"></strong><br><br>


<strong>Email<input name="email" type="text" id="email" value="Insert new email" size="15"></strong><br><br>


<strong>Clickz<input name="clickz" type="text" id="clickz" value="Insert new clickz"></strong><br><br>




<input name="player" type="hidden" id="player" value="<? echo $rows['player']; ?>">
<input type="submit" name="Submit" value="Submit">


</form>
</div>




<?

// close connection 
mysql_close();

?>





<?php
include("footer.php");
?>