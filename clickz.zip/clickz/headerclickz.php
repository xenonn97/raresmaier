<html>
<head>
<title>Clickz</title>
<link rel='stylesheet' href='style.css' type='text/css' />
<link rel='stylesheet' href='top.css' type='text/css' />
</head>

<BODY Background=../graphics/grayback.jpg onLoad="getTime()">


	
            <center><img src="img/logo.png"></center>

       

<div class="navrow">
<a href="index.php">&#8226; Home</a>
<a href="register.php"> &#8226; Inregistrare</a>
<a href="regulament.php"> &#8226; Regulament</a>
<a href="http://SCHIMBA IN HEADER.PHP SI HEADER_CLICKZ.PHP/forum/"> &#8226; Forum</a>
<a href="premii.php"> &#8226; Premii</a>
<a href="users.php"> &#8226; Participanti</a>
<a href="top100.php"> &#8226; Top 100</a>
<a href="statistici.php"> &#8226; Contul meu</a>
<a href="admin_login.php"> &#8226; Admin Account</a>
</div>

<br>



































<table width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
  <tr>
  <td width="100%" valign="top">
  
  
  
  <div class="block-start">
<div class="cap-div"><div class="cap-left"><div class="cap-right">
<?php
include("onlineusers.php");
?> - Clickz&nbsp;
</div></div></div>

<table class="tablebg" width="100%" cellspacing="0">

	<tr>
<td class="row2" nowrap="nowrap" onmouseover="this.className='row1'" onmouseout="this.className='row2'" >




  
  
 



























