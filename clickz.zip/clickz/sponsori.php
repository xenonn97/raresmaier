<?php
include("header.php");
?>

<div align="left">
<h3>Sponsorii Concursului <b> iReal Clickz </b>!</h3>
<br>
Aici vor aparea bannerele sponsorilor nostrii !
<br>

</div>



<?php
include("footer.php");
?>