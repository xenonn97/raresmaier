<? 
session_start();
if(!session_is_registered(myusername)){
header("location:admin_login.php");
}
?>


<?php
 include("header.php");
?>



<?php
include("connection.php");

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// get value of id that sent from address bar 
$id=$_GET['id'];

// Delete data in mysql from row that has this id 
$sql="DELETE FROM $tbl_name_users WHERE id='$id'";
$result=mysql_query($sql);

// if successfully deleted
if($result){
echo "<font face='Trebuchet Ms' size='4' color='green'>Deleted Successfully</font>";
echo "<BR>";
echo "<a href='admin_details.php'>Back to main page</a>";
}

else {
echo "<font face='Trebuchet Ms' size='4' color='red'>Deleted unSuccessfully</font>";
}

// close connection 
mysql_close();

?>




<?php
 include("footer.php");
?>