<?php
include("header.php");
?>
   
<div align="center">
<br>

<?php

// Conectare MySQL
require ('config.php');
// -------------------

// Variabile

if(!isset($_POST['username'])){ 
    $username = "????";
} else { 
    $username = $_POST['username'];
} 

if(!isset($_POST['password'])){ 
    $password = "????"; 
} else { 
    $password = $_POST['password'];
}

// -------------------

// Verificam daca userul exista in DB !

$verificare_username = "SELECT username FROM users WHERE username = '$username' AND password = '$password'";


$result_username = mysql_query($verificare_username);

if( mysql_num_rows($result_username) == 0 ) { // Verificare cont

echo "Userul sau parola sunt incorecte !";

} else {

print("<table>");
$stats = mysql_query("SELECT * FROM users WHERE username = '$username' AND password = '$password'");
while($row = mysql_fetch_array($stats))
  {
 
 $username = $row['username'];
 $email = $row['email'];
 $pass = $row['password'];
 $clickz = $row['clickz'];
 $date = $row['date'];
 print("<tr><td class='rules'><font size='1'>Username: $username </td></tr><tr><td class='rules'><font size='1'>Parola: $pass </td></tr><tr><td class='rules'><font size='1'>Email: $email </td></tr><tr><td class='rules'><font size='1'>Clickz: $clickz </td></tr><tr><td class='rules'><font size='1'>Inregistrat: $date </td></tr>
 <tr><td class='rules'><br><br>Link-ul tau: <input name='link' type='text' size='65' value='http://www.ireal.in/clickz.php?player=$username'/></td></tr>");

}
 print("</table>");
 }
?>

<br>
</div> 

<?php
include("footer.php");
?>
