<?php
include("header.php");
?>

<div align="left">
<h3>Bun venit pe iReal !</h3>
<br>
<h4>Pe acest site poti castiga premii cu ajutorul voturilor acordate de prietenii tai . <br>
Acestia te pot vota folosind link-ul tau , primit la inregistrare , si afisat si la sectiunea "<a href="http://ireal.in/statistici.php">Contul meu</a>" dupa ce te-ai logat !
</h4>
<br>
<h3>Premiile puse in joc :</h3><br>

<img src="../img/1.png"> </h4>Un tricou personalizat cu site-ul iReal .
<br>
<img src="../img/2.png"> Set 12 stickere cu site-ul Ireal .
<br>
<img src="../img/3.png"> 1.000 clickz-uri la urmatorul concurs de luna viitoare .</h4>
<br>

</div>



<?php
include("footer.php");
?>