<?php
include("header.php");
?>

<div align="left">
<h3>Contact !</h3>
<br>
Vrei sa iei legatura cu echipa iReal ?
<br>
Este foarte simplu , trimite un e-mail la adresa : <b> ro_playpro@yahoo.com </b> iar noi te vom contacta apoi . 

<br>

Multumim , cu drag echipa iReal !



</div>



<?php
include("footer.php");
?>