<?php

// Conectare MySQL
require ('config.php');
// -------------------

// Variabile

if(!isset($_POST['username'])){ 
    $username = "default";
} else { 
    $username = $_POST['username'];
} 

if(!isset($_POST['password'])){ 
    $password = "default"; 
} else { 
    $password = $_POST['password'];
}

if(!isset($_POST['email'])){ 
    $email = "default"; 
} else { 
    $email = $_POST['email'];
}


$date = date('Y.m.d');
$userip = $_SERVER['REMOTE_ADDR'];

// -------------------

// Verificam daca userul exista in DB !

$verificare_username = "SELECT username FROM users WHERE username = '$username'";
$verificare_ip = "SELECT ip FROM users WHERE ip = '$userip'";
$verificare_email = "SELECT email FROM users WHERE email = '$email'";

$result_username = mysql_query($verificare_username);
$result_ip = mysql_query($verificare_ip);
$result_email = mysql_query($verificare_email);

if(mysql_num_rows($result_username) == 0) { // Verificare username

  if(mysql_num_rows($result_email) == 0) { // Verificare email
    
	if(mysql_num_rows($result_ip) == 0) { // Verificare IP
	
	mysql_query("INSERT INTO users (id, username, password, email, clickz, date, ip, status) 
	VALUES ('', '$username', '$password', '$email', '0', '$date', '$userip', '1')");
	$mesaj = "Contul a fost creat cu succes !<br><br><br>Link-ul tau: <input name='link' type='text' size='65' value='http://www.ireal.in/clickz.php?player=$username'/>";
	} 
	else { $mesaj = "A fost deja creat un cont de pe aceasta adresa IP!"; } }
	else { $mesaj = "Aceasta adresa de email este deja folosita !<br> Te rog sa alegi alta.";
	}
    }
else {
$mesaj = "Acest username este deja folosit !<br> Te rog sa alegi altul.";
}

?>
<?php
include("header.php");
?>
   
<div align="center">
<br>
<h2><?php echo $mesaj; ?></h2>
<br>
</div> 
<?php
include("footer.php");
?>