<?php
include("header.php");
?>
<div align="center">
<?php

if(!isset($_GET['player'])){
    $player = "???";
} else {
    $player = $_GET['player'];
}
print("<h3>Apasa butonul de mai jos pentru a acorda un clickz lui $player</h3>");
print("<form method='post' action='take_clickz.php'>");
print("<input name='player' type='hidden' value='$player'/>");
print("<input type='submit' value='Acorda un clickz'/>");
print("</form>");
?>
<br>
</div>

<?php
include("footer.php");
?>