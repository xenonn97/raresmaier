<?php
include("connection.php");

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// update data in mysql database 
$sql="UPDATE $tbl_name_users SET username='$username', password='$password', email='$email', clickz='$clickz' WHERE id='$id'";
$result=mysql_query($sql);

// if successfully updated. 
if($result){
echo "<font color='green' size='4'>Successful</font>";
echo "<BR>";
echo "<a href='admin_details.php'>View result</a>";
}

else {
echo "<font color='red' size='4'>ERROR</font>";
}

?>