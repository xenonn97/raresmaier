<html>
<head>
<title>Top 15 Clickz</title>
<link rel='stylesheet' href='top.css' type='text/css' />
</head>
<body>
<div style="position: absolute; width: 175px; height: 330px; z-index: 1; left: -7px; top: 0px">
<div id="back">
<table width="175px">

<tr><td class='rank'>Rank</td><td class='username'>Concurent</td><td class='clickz'>Clickz</td></tr>
<?php

// Conectare MySQL
require ('config.php');
//

$result = mysql_query("SELECT * FROM users ORDER BY clickz DESC LIMIT 15");

$rank = 1;
while($row = mysql_fetch_array($result))
  {
  $username = $row['username'];
  $clickz = $row['clickz'];
  print("<tr><td class='rank'>$rank</td><td class='username'>$username</td><td class='clickz'>$clickz</td></tr>");
  $rank++;
  }
?>
</table>
</div>
</div>
</body>
</html>