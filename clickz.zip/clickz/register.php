<?php
include("header.php");
?>
   
<div align="center">
<br>         
<form action="take_register.php" method="post">


<img src="img/user.png"><input name="username" type="text" size="30" maxlength="20" id="username" class="tbox" />
<br><br>
<img src="img/pass.png"><input name="password" type="password" size="30" maxlength="20" id="password" class="tbox" />
<br><br>
<img src="img/mail.png"><input name="email" type="text" size="30" maxlength="40" id="email" class="tbox" />
<br><br>

<br><input name="submit" type="submit" value="Inregistrare" class="button" />


</form>
<br>
</div> 

<?php
include("footer.php");
?>