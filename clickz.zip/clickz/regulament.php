<?php
include("header.php");
?>
   
<div align="center">
<font size="1">Reguli Generale!</font>
<br />
<table>
<tr><td class="rules"><font size="1">1. Un singur cont pentru fiecare.</font></td></tr>
<tr><td class="rules"><font size="1">2. Este interzisa folosirea de proxy.</font></td></tr>
<tr><td class="rules"><font size="1">3. Este interzisa atragerea de voturi (frage) facand spam.</font></td></tr>
<tr><td class="rules"><font size="1">4. Cei prinsi ca se voteaza singuri (cei cu ip dinamic .. ClickNET, RDS, etc.) vor fi exclusi din concurs.</font></td></tr>
</table>
</div> 

<?php
include("footer.php");
?>