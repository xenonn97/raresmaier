<? 
session_start();
if(!session_is_registered(myusername)){
header("location:admin_login.php");
}
?>


<?php
include("header.php");
?>




<table width="300" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><form name="form1" method="post" action="admin_addadmin_mysql.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
<td colspan="3"><strong>Insert Admin</strong></td>
</tr>
<tr>
<td width="71">Username</td>
<td width="6">:</td>
<td width="301"><input name="username" type="text" id="username"></td>
</tr>
<tr>
<td>Password</td>
<td>:</td>
<td><input name="password" type="password" id="password"></td>
</tr>
<tr>
<td colspan="3" align="center"><input type="submit" name="Submit" value="Submit"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>





<?php
include("footer.php");
?>